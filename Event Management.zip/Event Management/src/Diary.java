import java.util.LinkedList;

public class Diary {

	public LinkedList<Event> myEvents;
	
	public Diary() 
	{
		
		myEvents = new LinkedList<Event>();
		
	}
}

public class Tree {

	private TreeNode root;
	
	public Tree() 
	{
		
		root = null;
		
	}
	
}

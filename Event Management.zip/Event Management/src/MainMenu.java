import java.util.Stack;

public class MainMenu {

	private Stack<Tree> myStack;
	
	
	public void MainMenu()
	{
		
		myStack = new Stack<Tree>();
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

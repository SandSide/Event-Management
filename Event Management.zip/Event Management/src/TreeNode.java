import java.util.LinkedList;

public class TreeNode {
	
	public String name;
	public LinkedList<Diary> myDiary;

	public TreeNode()
	{
		
		myDiary = new LinkedList<Diary>();
		
	}
	
}

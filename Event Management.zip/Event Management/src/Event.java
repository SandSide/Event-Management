import java.util.Date;

public class Event {

	private Date date; 
	//private Time starttime;
	//private time endtime;
	private String desciption;
	private int capacity;
}
